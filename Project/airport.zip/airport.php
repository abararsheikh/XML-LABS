<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Airport</title>
    <style>
        table,th,td
        {
            border : 1px solid black;
            border-collapse: collapse;
        }
        th,td
        {
            padding: 5px;
            text-align: center;
        }
    </style>
</head>
<body>
<h3 style="color: red">Only one hit per 50 seconds is allowed against this page.</h3>
<h2>Click on a Flight Number to display Flight Information.</h2>
<h1>Flight Details</h1>
<span style="font-size: 18px;color: #F44336">
<p id='showFlight'></p>
</span>
<table id="flightInfo"></table>

<script>
    // use not2.html Example
    var x,xmlhttp,xmlDoc,i
    xmlhttp = new XMLHttpRequest();
    xmlhttp.open("GET", "air.php", false);  //load the file from the curl request
    xmlhttp.send();
    xmlDoc = xmlhttp.responseXML;    //get the response

//    console.log(xmlDoc);
    var FlightData = xmlDoc.getElementsByTagName("Header");    //get the header element

    table="<tr><th>FlightNumber</th><th>Arrival || Departure</th></tr>";

    for (i = 0; i < FlightData.length; i++)
    {
        table += "<tr onclick='displayFlight(" + i + ")'><td>";
        table +=FlightData[i].getElementsByTagName("FlightNumber")[0].childNodes[0].nodeValue;
        table += "</td><td>";
        table +=FlightData[i].getElementsByTagName("ArrivalOrDeparture")[0].childNodes[0].nodeValue;
        //  table += "</td><td>";
    }

    document.getElementById("flightInfo").innerHTML = table;
    function displayFlight(i){
        document.getElementById("showFlight").innerHTML =
            "<span style='font-weight: bold'>FlightNumber : </span>" + FlightData[i].getElementsByTagName("FlightNumber")[0].childNodes[0].nodeValue +
            "<br><span style='font-weight: bold'>Host Airport City (origin): </span>" + FlightData[i].getElementsByTagName("HostAirportCity")[0].childNodes[0].nodeValue +
            "<br><span style='font-weight: bold'>Destination City (To):</span> " + FlightData[i].getElementsByTagName("Comments")[0].childNodes[0].nodeValue +
            "<br><span style='font-weight: bold'>Flight Date :</span> " + FlightData[i].getElementsByTagName("FlightDate")[0].childNodes[0].nodeValue +
            "<br><span style='font-weight: bold'>Arrival Or Departure :</span> " + FlightData[i].getElementsByTagName("ArrivalOrDeparture")[0].childNodes[0].nodeValue +
            "<br><span style='font-weight: bold'>Via Airport City :</span> " + FlightData[i].getElementsByTagName("ViaAirportCity")[0].childNodes[0].nodeValue +
            "<br><span style='font-weight: bold'>Status (OnTime or delayed) :</span> " + FlightData[i].getElementsByTagName("Status")[0].childNodes[0].nodeValue +
            "<br><span style='font-weight: bold'>Via Airport Code :</span> " + FlightData[i].getElementsByTagName("ViaAirportCode")[0].childNodes[0].nodeValue +
            "<br><span style='font-weight: bold'>Estimated Time :</span> " + FlightData[i].getElementsByTagName("EstimatedTime")[0].childNodes[0].nodeValue +
            "<br><span style='font-weight: bold'>Airline Code :</span> " + FlightData[i].getElementsByTagName("AirlineCode")[0].childNodes[0].nodeValue +
            "<br><span style='font-weight: bold'>Server UTC Time :</span> " + FlightData[i].getElementsByTagName("ServerUTCTime")[0].childNodes[0].nodeValue ;

    }
</script>
</body>
</html>
